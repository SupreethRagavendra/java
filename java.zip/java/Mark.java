import java.util.Scanner;
public class Mark {
    public static void main(String[] args)
    {
        int choice;
        Scanner sc =new Scanner(System.in);
        do
        {
            System.out.println("Menu");
            System.out.println("1.Enter the Student Marks");
            System.out.println("2. Exit");
            System.out.println("Enter your choice: (1 or 0)");
            choice=sc.nextInt();
            switch (choice)
            {
                case 1:
                    System.out.println("Enter student mark (out of 100)");
                    int mark=sc.nextInt();
                    if (mark>=90)
                    {
                        System.out.println("This is good");

                    }
                    else if(mark>=60)
                    {
                        System.out.println("This is also good ");
                    }
                    else if(mark >=0)
                    {
                        System.out.println("This is good as well");

                    }
                    else {
                        System.out.println("Invalid Mark entered.Mark should be 0 to 100");

                    }

                    break;
                case 2:
                    System.out.println("Exiting program goodbye");

                    break;

                default:
                    System.out.println("Invalid choice .please enter 1 or 0");
break;

            }

        }while(choice!=0);
        sc.close();
    }
}

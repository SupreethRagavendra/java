import java.util.*;
public class NaturalNo {
    public static void main(String[] args)
    {

    System.out.println("First Natural Numbers");
   
 
 System.out.print("Enter the  num ");
    Scanner sc =new Scanner(System.in);
 int num=sc.nextInt();
 int sum=0;
 for(int i=0;i<=num;i++)
 {
    sum=sum+i;
 
 }
System.out.println(sum);
 

    }
    

}
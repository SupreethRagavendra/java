class Loop2
{
    public static void main(String[] args)
   {

    for(int counter =0; counter<10 ; counter=counter +1)
    {
        System.out.println("Welcome");

    }
   }
   }
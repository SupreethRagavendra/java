import java.util.*;
public class Even {
    public static void main(String args[])
    {
        
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter value for n:");
        int n=sc.nextInt();

        System.out.println("Even number upto "+n+":");
        for(int i=2; i<n; i+=2)
        {
            System.out.println(i+"");

        }
    }
    
}

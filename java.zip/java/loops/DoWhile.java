public class DoWhile {
    
    public static void main(String[] args)
    {    int a=0;  
        do 
        {
      
            System.out.print(a +" ");
           a=a+1;
          

        } while(a<=20);
    }
}

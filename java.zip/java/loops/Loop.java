class Loop
{
    public static void main(String[] args)
    {
    for(int a=5; a>0;a--)
    {
        System.out.println("Hello World ");

    }
    }
}
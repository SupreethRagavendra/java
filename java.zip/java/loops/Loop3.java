public class Loop3 {
    
    public static void main(String[] args)
    {
        //for(int count = 0; count<=10; count++)
       // {
          //  System.out.print(count);

      //  }
      for(int a = 0; a<11; a++)
      {
        System.out.println(a*2);
      }
    }

}

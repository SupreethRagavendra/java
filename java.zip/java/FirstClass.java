class FirstClass
{
    public static void main(String[] args)

    { //output
        System.out.print("hello world \n ");
        System.out.print("Hello World \n");
        System.out.println("Hello World ");

    }
}
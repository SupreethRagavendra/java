import java.util.*;
public class Input {
    public static void main(String[] args)
    {
        Scanner sc =new Scanner(System.in);
        String name=sc.nextLine();
        System.out.println(name);
//nextInt();
        //nextFloat();
        //nextDouble();


    }
}

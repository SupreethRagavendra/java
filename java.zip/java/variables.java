public class variables {
    public  static void main(String[] args)

    {
        //variables
      int a=10;
      int b=10;
      int sum=a+b;
      int mul=a*b;
        System.out.println(mul);

        System.out.println(sum);




    }

}

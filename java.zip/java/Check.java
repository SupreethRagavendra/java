import java.util.*;
public class Check {
    public static void main(String[] args)
    {

    Scanner sc = new Scanner(System.in);
    int a = sc.nextInt();
    int b= sc.nextInt();
    if (a==b)
    {
        System.out.print("Equal");

    }
    else if (a > b) {
            System.out.print("A is greater ");
        }

    else
        {
            System.out.print("A is lesser");
        }
}}

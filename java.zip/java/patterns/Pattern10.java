public class Pattern10 {
    public static void main(String[] args)
    {
        
    }
}

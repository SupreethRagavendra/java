import java.util.Scanner;
public class Test1 {


    public static int PrintMyName(String name) {
        System.out.print(name);
        return  1;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        PrintMyName(name);

    }
}
import java.util.Scanner;
public class Prac1 {

    public static void MyNumbers(int a, int b, int c)

    {
        System.out.println("MY numbers");
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);

    }
    public  static  void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int a= sc.nextInt();
        int b= sc.nextInt();
        int c= sc.nextInt();
        MyNumbers(a,b,c);


    }

}

import java.util.Scanner;

public class Prac4 {




        public static void GetGreater(int a,int b) {
            if (a > b) {
                System.out.println("A greater than b");
            } else {
                System.out.print("A is less than b");

            }
        }
        public static void main(String[] args) {

            Scanner sc = new Scanner(System.in);

            int a = sc.nextInt();
            int b = sc.nextInt();
            GetGreater(a,b);




        }

    }


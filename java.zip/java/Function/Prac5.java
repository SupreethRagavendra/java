public class Prac5
{
    public  static  void main(String[] args)
    {
        do {

System.out.print("hi");
        }while(true);
    }
}

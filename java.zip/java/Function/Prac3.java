import java.util.Scanner;

public class Prac3 {







        public static void GetGreater(int x,int n) {

            int res = 1;
            for (int i = 1; i <= n; i++) {
                res = res * x;


            }
            System.out.print(res);
        }
        public static void main(String[] args) {

            Scanner sc = new Scanner(System.in);

            System.out.print("Enter x");

            int x = sc.nextInt();

            System.out.print("Enter n");

            int n = sc.nextInt();
            GetGreater(x,n);




        }

    }



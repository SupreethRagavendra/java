import java.util.*;
public class Test5 {
    public  static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        int btn = sc.nextInt();
        switch(btn)
   {
            case 1:
                System.out.print("hello");
                break;

            case 2:
                System.out.print("Namaste");
                break;
            case 3:
                System.out.print("Bonjour");
                break;

            default:
                System.out.println("Invalid Button");


        }


    }}

